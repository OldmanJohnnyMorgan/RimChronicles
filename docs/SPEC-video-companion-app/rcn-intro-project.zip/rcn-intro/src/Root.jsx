import React from 'react';
import { Composition } from 'remotion';
import { RcnIntro } from './RcnIntro';
import bulletin from './bulletin.json';

export const RemotionRoot = () => (
  <Composition
    id="RcnIntro"
    component={RcnIntro}
    durationInFrames={480}
    fps={30}
    width={1920}
    height={1080}
    defaultProps={{ bulletin, showCaptions: true }}
  />
);
