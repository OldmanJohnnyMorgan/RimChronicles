import React from 'react';
import {
  AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile,
  useCurrentFrame, useVideoConfig, Easing,
} from 'remotion';
import { Pawn } from './Pawn';

// ── Palette & type ──────────────────────────────────────────────
const C = {
  bg0: '#07090d', bg1: '#121822', red: '#c8312b', redDark: '#7d1a16',
  gold: '#e3b04b', ink: '#f2efe8', mute: '#8f98a6', line: 'rgba(242,239,232,0.12)',
};
const DISPLAY = 'Anton, "Archivo Black", sans-serif';
const SANS = '"Fira Sans", "DejaVu Sans", sans-serif';
const MONO = '"Anonymous Pro", "DejaVu Sans Mono", monospace';

const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' };
const ease = Easing.bezier(0.22, 1, 0.36, 1);

// ── Background: dark field, faint grid, a slowly turning rim-world ──
const Backdrop = () => {
  const f = useCurrentFrame();
  const sweep = interpolate(f, [0, 70], [-40, 140], { ...clamp, easing: ease });
  const planetIn = interpolate(f, [0, 50], [0, 1], clamp);
  return (
    <AbsoluteFill style={{ background: `radial-gradient(ellipse at 60% 45%, ${C.bg1} 0%, ${C.bg0} 70%)` }}>
      <AbsoluteFill style={{
        backgroundImage: `linear-gradient(${C.line} 1px, transparent 1px), linear-gradient(90deg, ${C.line} 1px, transparent 1px)`,
        backgroundSize: '80px 80px', opacity: 0.35,
        maskImage: 'radial-gradient(ellipse at center, black 30%, transparent 75%)',
        WebkitMaskImage: 'radial-gradient(ellipse at center, black 30%, transparent 75%)',
      }} />
      {/* planet */}
      <div style={{
        position: 'absolute', width: 900, height: 900, right: -180, top: 90,
        borderRadius: '50%', opacity: 0.55 * planetIn,
        background: `radial-gradient(circle at 35% 35%, #2a3444 0%, #0c1017 62%)`,
        boxShadow: `inset -40px -30px 120px rgba(0,0,0,0.8), 0 0 120px rgba(200,49,43,0.18)`,
        transform: `rotate(${f * 0.05}deg)`,
      }}>
        <div style={{
          position: 'absolute', inset: -6, borderRadius: '50%',
          border: `3px solid ${C.red}`, opacity: 0.35,
          clipPath: 'polygon(0 0, 55% 0, 55% 100%, 0 100%)',
        }} />
      </div>
      {/* orbital ring */}
      <div style={{
        position: 'absolute', width: 1500, height: 260, right: -480, top: 410,
        borderRadius: '50%', border: `2px solid rgba(227,176,75,0.35)`,
        transform: `rotate(-12deg) scale(${0.9 + 0.1 * planetIn})`, opacity: planetIn,
      }} />
      {/* light sweep */}
      <AbsoluteFill style={{
        background: `linear-gradient(100deg, transparent ${sweep - 15}%, rgba(255,255,255,0.08) ${sweep}%, transparent ${sweep + 15}%)`,
      }} />
      {/* scanlines + vignette */}
      <AbsoluteFill style={{
        backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.18) 0 2px, transparent 2px 4px)', opacity: 0.4,
      }} />
      <AbsoluteFill style={{ boxShadow: 'inset 0 0 260px rgba(0,0,0,0.85)' }} />
    </AbsoluteFill>
  );
};

// ── Main logo slam (frames 60–200 local to its Sequence) ─────────
const LogoSlam = ({ d }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: f, fps, config: { damping: 12, stiffness: 140, mass: 0.8 } });
  const scale = interpolate(s, [0, 1], [2.4, 1]);
  const bar = interpolate(f, [6, 26], [0, 1], { ...clamp, easing: ease });
  const sub = interpolate(f, [18, 38], [0, 1], clamp);
  const tag = interpolate(f, [55, 75], [0, 1], clamp);
  // shrink away into the corner bug
  const out = interpolate(f, [105, 135], [0, 1], { ...clamp, easing: ease });
  const flash = interpolate(f, [0, 3, 12], [0, 0.55, 0], clamp);

  return (
    <AbsoluteFill style={{ alignItems: 'center', justifyContent: 'center' }}>
      <AbsoluteFill style={{ background: '#fff', opacity: flash }} />
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        transform: `translate(${-700 * out}px, ${-400 * out}px) scale(${scale * (1 - 0.75 * out)})`,
        opacity: 1 - out,
      }}>
        <div style={{
          fontFamily: DISPLAY, fontSize: 300, lineHeight: 0.9, color: C.ink, letterSpacing: 18,
          textShadow: `0 10px 40px rgba(0,0,0,0.6)`,
        }}>
          RC<span style={{ color: C.red }}>N</span>
        </div>
        <div style={{ height: 14, width: 760 * bar, background: C.red, marginTop: 18, boxShadow: `0 0 30px ${C.red}` }} />
        <div style={{
          fontFamily: SANS, fontWeight: 600, fontSize: 46, letterSpacing: 22, color: C.ink,
          marginTop: 26, opacity: sub, transform: `translateY(${(1 - sub) * 20}px)`,
        }}>
          {d.networkFull.toUpperCase()}
        </div>
        <div style={{
          fontFamily: SANS, fontStyle: 'italic', fontWeight: 300, fontSize: 34, color: C.gold,
          marginTop: 22, opacity: tag,
        }}>
          {d.tagline}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ── Persistent corner bug + LIVE + dateline ──────────────────────
const Chrome = ({ d }) => {
  const f = useCurrentFrame();
  const a = interpolate(f, [0, 15], [0, 1], clamp);
  const blink = Math.floor(f / 15) % 2 === 0 ? 1 : 0.35;
  return (
    <AbsoluteFill style={{ opacity: a }}>
      <div style={{ position: 'absolute', left: 70, top: 60, display: 'flex', alignItems: 'center', gap: 18 }}>
        <div style={{ fontFamily: DISPLAY, fontSize: 72, color: C.ink, letterSpacing: 6, lineHeight: 1 }}>
          RC<span style={{ color: C.red }}>N</span>
        </div>
        <div style={{
          fontFamily: SANS, fontWeight: 700, fontSize: 22, color: '#fff', background: C.red,
          padding: '6px 14px', letterSpacing: 4, display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ width: 12, height: 12, borderRadius: 6, background: '#fff', opacity: blink }} /> LIVE
        </div>
      </div>
      <div style={{
        position: 'absolute', right: 70, top: 66, textAlign: 'right', fontFamily: MONO, color: C.ink,
      }}>
        <div style={{ fontSize: 30 }}>{d.dateline}</div>
        <div style={{ fontSize: 22, color: C.mute, marginTop: 6 }}>{d.location}</div>
      </div>
    </AbsoluteFill>
  );
};

// ── Bottom ticker ────────────────────────────────────────────────
const Ticker = ({ d }) => {
  const f = useCurrentFrame();
  const rise = interpolate(f, [0, 18], [80, 0], { ...clamp, easing: ease });
  const text = d.ticker.join('   ◆   ');
  const x = 1920 - f * 5.5;
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, height: 72,
      transform: `translateY(${rise}px)`, display: 'flex', background: 'rgba(7,9,13,0.92)',
      borderTop: `3px solid ${C.red}`,
    }}>
      <div style={{
        background: C.red, color: '#fff', fontFamily: DISPLAY, fontSize: 36, letterSpacing: 4,
        padding: '0 30px', display: 'flex', alignItems: 'center', zIndex: 2,
        boxShadow: '12px 0 24px rgba(0,0,0,0.6)',
      }}>RIM WIRE</div>
      <div style={{ position: 'relative', flex: 1, overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', top: 0, bottom: 0, display: 'flex', alignItems: 'center',
          whiteSpace: 'nowrap', transform: `translateX(${x}px)`,
          fontFamily: SANS, fontWeight: 500, fontSize: 32, color: C.ink,
        }}>
          {text}   ◆   {text}
        </div>
      </div>
    </div>
  );
};

// ── Reporter lower third ─────────────────────────────────────────
const LowerThird = ({ d }) => {
  const f = useCurrentFrame();
  const bar = interpolate(f, [0, 16], [0, 1], { ...clamp, easing: ease });
  const txt = interpolate(f, [10, 26], [0, 1], clamp);
  const out = interpolate(f, [100, 115], [0, 1], clamp);
  return (
    <div style={{ position: 'absolute', left: 70, bottom: 190, opacity: 1 - out }}>
      <div style={{
        background: C.ink, color: C.bg0, padding: '14px 34px 10px', fontFamily: DISPLAY, fontSize: 56,
        letterSpacing: 2, clipPath: `inset(0 ${100 - bar * 100}% 0 0)`,
      }}>
        {d.reporter.name.toUpperCase()}
      </div>
      <div style={{
        background: C.red, color: '#fff', padding: '8px 34px', fontFamily: SANS, fontWeight: 600,
        fontSize: 26, letterSpacing: 6, display: 'inline-block', opacity: txt,
        transform: `translateX(${(1 - txt) * -30}px)`,
      }}>
        {d.reporter.title.toUpperCase()} · RCN
      </div>
    </div>
  );
};

// ── Headline card ────────────────────────────────────────────────
const Headline = ({ d }) => {
  const f = useCurrentFrame();
  const a = interpolate(f, [0, 18], [0, 1], { ...clamp, easing: ease });
  const k = interpolate(f, [24, 40], [0, 1], clamp);
  return (
    <div style={{
      position: 'absolute', left: 70, top: 300, width: 1050,
      transform: `translateX(${(1 - a) * -80}px)`, opacity: a,
    }}>
      <div style={{
        display: 'inline-block', fontFamily: SANS, fontWeight: 700, fontSize: 26, letterSpacing: 6,
        color: C.bg0, background: C.gold, padding: '6px 16px',
      }}>TONIGHT ON RCN</div>
      <div style={{
        fontFamily: DISPLAY, fontSize: 104, lineHeight: 1.02, color: C.ink, marginTop: 22,
        textShadow: '0 8px 30px rgba(0,0,0,0.7)',
      }}>
        {d.headline}
      </div>
      <div style={{
        fontFamily: SANS, fontStyle: 'italic', fontWeight: 400, fontSize: 48, color: C.gold,
        marginTop: 18, opacity: k,
      }}>
        {d.kicker}
      </div>
    </div>
  );
};

// ── Captions (stand-in for TTS until voices exist) ───────────────
const Captions = ({ d }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const lines = d.narration;
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    const end = i + 1 < lines.length ? lines[i + 1].atSec : 15.2;
    if (t >= lines[i].atSec && t < end) cur = { ...lines[i], start: lines[i].atSec, end };
  }
  if (!cur) return null;
  const local = t - cur.start;
  const a = Math.min(1, local / 0.25, (cur.end - t) / 0.25);
  return (
    <div style={{
      position: 'absolute', left: 70, bottom: 96, display: 'flex', justifyContent: 'flex-start',
      opacity: Math.max(0, a),
    }}>
      <div style={{
        maxWidth: 1080, textAlign: 'left', fontFamily: SANS, fontSize: 36, color: C.ink,
        background: 'rgba(7,9,13,0.75)', padding: '10px 24px', borderRadius: 4,
      }}>
        <span style={{ color: C.red, fontWeight: 700, marginRight: 12 }}>{cur.voice === 'news' ? 'VALE:' : 'NARRATOR:'}</span>
        {cur.text}
      </div>
    </div>
  );
};


// ── Reporter pawn on set ─────────────────────────────────────────
const Reporter = ({ d, startSec }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps + startSec;
  const s = spring({ frame: f, fps, config: { damping: 15, stiffness: 90 } });
  const x = interpolate(s, [0, 1], [500, 0]);
  const glow = interpolate(f, [0, 30], [0, 1], clamp);
  // talking while a line is being read (approx. 0.38 s per word)
  const talking = d.narration.some(
    (l) => t >= l.atSec && t < l.atSec + l.text.split(' ').length * 0.38
  );
  return (
    <div style={{ position: 'absolute', right: 140, bottom: 60, transform: `translateX(${x}px)` }}>
      <div style={{
        position: 'absolute', left: -120, right: -120, top: 40, bottom: -10, opacity: glow,
        background: 'radial-gradient(ellipse at 50% 55%, rgba(227,176,75,0.22) 0%, rgba(200,49,43,0.10) 40%, transparent 70%)',
      }} />
      <Pawn talking={talking} size={560} />
    </div>
  );
};

// ── Composition ──────────────────────────────────────────────────
export const RcnIntro = ({ bulletin: d, showCaptions = true }) => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const fadeOut = interpolate(f, [durationInFrames - 24, durationInFrames - 1], [1, 0], clamp);
  const fadeIn = interpolate(f, [0, 12], [0, 1], clamp);

  return (
    <AbsoluteFill style={{ background: C.bg0 }}>
      <AbsoluteFill style={{ opacity: fadeIn * fadeOut }}>
        <Backdrop />
        <Sequence from={60} durationInFrames={140}><LogoSlam d={d} /></Sequence>
        <Sequence from={190}><Chrome d={d} /></Sequence>
        <Sequence from={200}><Reporter d={d} startSec={200 / 30} /></Sequence>
        <Sequence from={180}><Ticker d={d} /></Sequence>
        <Sequence from={215} durationInFrames={120}><LowerThird d={d} /></Sequence>
        <Sequence from={325}><Headline d={d} /></Sequence>
        {showCaptions && <Captions d={d} />}
      </AbsoluteFill>
      <Audio src={staticFile('sting.wav')} volume={0.9} />
      {d.voiceSrc && <Audio src={staticFile(d.voiceSrc)} volume={1} />}
    </AbsoluteFill>
  );
};
