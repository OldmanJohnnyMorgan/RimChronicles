# RCN Intro — Rim Chronicles test video

A 16-second broadcast intro for **Rim Chronicle News**. This is the first test of the `news_bulletin` template from `SPEC-epilogue-video-companion.md`.

## Run it

```bash
npm install
npx remotion studio src/index.js                                   # live preview + scrub
npx remotion render src/index.js RcnIntro out/RCN-intro.mp4        # render MP4
```

## What drives it

Every text in the video comes from `src/bulletin.json`: reporter, dateline, headline, ticker and narration lines. Later the chronicle will fill this file instead of you. No code change needed.

## Timeline (30 fps, 480 frames)

| Time | Shot | Sound |
| --- | --- | --- |
| 0–2 s | Dark field, rim-world planet and orbit fade in, light sweep | Rising whoosh |
| 2–6 s | **RCN** slams in with white flash, red bar wipes, "RIM CHRONICLE NEWS" + tagline | Low hit at 2 s, 3-note chime at ~4.2 s |
| 5.5–6.5 s | Logo flies to the top-left corner bug | Drone bed starts |
| 6 s → end | Bug + LIVE badge, dateline top right, RIM WIRE ticker scrolls | Bed |
| 7–11 s | Reporter lower third: DESMOND VALE, Field Correspondent | |
| 11 s → end | "TONIGHT ON RCN" headline card + kicker | |
| 15.2–16 s | Fade to black | Bed fades |

## Narration script (news-agent voice)

| At | Line |
| --- | --- |
| 5.2 s | "This is Rim Chronicle News." |
| 7.4 s | "Every three days, from every corner of the rim. I'm Desmond Vale." |
| 11.0 s | "Tonight: whispers from the old Imperial holdings. Is the Empire waking up?" |

Delivery: brisk, confident broadcast read. Slight pause before "Is the Empire waking up?"

**No voice yet.** Couldn't download TTS voice models in the build environment, so the lines show as captions. To add the voice:

1. Generate one WAV of all three lines with Piper or Kokoro, timed to start at 5.2 s (or pad the start with silence).
2. Drop it in `public/` and set `"voiceSrc": "vale.wav"` in `bulletin.json`.
3. Optionally set `showCaptions: false` in `src/Root.jsx`.

## Files

- `src/RcnIntro.jsx` — the template (backdrop, logo slam, corner bug, ticker, lower third, headline, reporter, captions)
- `src/Pawn.jsx` — the reporter pawn (SVG, RimWorld-like style: no arms, floating mic). Props for skin, hair, jacket and tie colours; animates breathing, blinking, and talking while a narration line plays
- `src/bulletin.json` — the content
- `public/sting.wav` — synthesized news sting + bed (made with ffmpeg; replace with real music any time)

The reporter name "Desmond Vale" is a placeholder. Swap it for the mod's actual news agent.
