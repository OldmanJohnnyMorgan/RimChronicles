import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';

// Original reporter pawn drawn in a RimWorld-like style:
// flat fills, thick dark outlines, no arms, held item floats beside the body.
const OUT = '#16120f';
const SW = 5;

export const Pawn = ({
  skin = '#e6b38c', hair = '#3a2416', jacket = '#2c3c58', jacketShade = '#223049',
  shirt = '#ece8df', tie = '#c8312b', talking = false, size = 520,
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();

  // idle breathing bob + extra nod while talking
  const bob = Math.sin((f / fps) * Math.PI * 1.2) * 2.5;
  const nod = talking ? Math.sin((f / fps) * Math.PI * 5) * 2.2 : 0;
  // blink every ~3.3 s
  const cycle = f % 100;
  const blink = cycle > 95 ? interpolate(cycle, [95, 97, 99], [1, 0.1, 1], { extrapolateRight: 'clamp' }) : 1;
  // mic floats and drifts a little
  const micY = Math.sin((f / fps) * Math.PI * 0.9 + 1) * 3;

  return (
    <svg viewBox="0 0 220 270" width={size} height={size * 270 / 220} style={{ overflow: 'visible' }}>
      {/* ground shadow */}
      <ellipse cx="105" cy="252" rx="62" ry="10" fill="rgba(0,0,0,0.45)" />

      <g transform={`translate(0 ${bob})`}>
        {/* body */}
        <path
          d="M42 246 C38 200 44 160 70 146 C84 139 126 139 140 146 C166 160 172 200 168 246 Z"
          fill={jacket} stroke={OUT} strokeWidth={SW} strokeLinejoin="round"
        />
        {/* jacket side shading */}
        <path d="M150 158 C162 176 165 210 163 244 L146 244 C148 210 148 182 150 158 Z" fill={jacketShade} />
        {/* shirt V + tie */}
        <path d="M86 143 L105 186 L124 143 Z" fill={shirt} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
        <path d="M100 152 L110 152 L113 182 L105 194 L97 182 Z" fill={tie} stroke={OUT} strokeWidth={3.5} strokeLinejoin="round" />
        {/* lapels */}
        <path d="M86 143 L98 170 L90 178 L78 150 Z" fill={jacketShade} stroke={OUT} strokeWidth={3.5} strokeLinejoin="round" />
        <path d="M124 143 L112 170 L120 178 L132 150 Z" fill={jacketShade} stroke={OUT} strokeWidth={3.5} strokeLinejoin="round" />
        {/* press badge */}
        <rect x="128" y="190" width="24" height="15" rx="2" fill={shirt} stroke={OUT} strokeWidth={3} />
        <rect x="131" y="193" width="18" height="4" fill={tie} />

        {/* head */}
        <g transform={`translate(0 ${nod})`}>
          <ellipse cx="105" cy="88" rx="50" ry="56" fill={skin} stroke={OUT} strokeWidth={SW} />
          {/* hair: side-parted, swept */}
          <path
            d="M56 84 C50 44 78 24 110 26 C140 28 160 46 156 80 C150 64 138 56 124 54 C112 62 88 60 74 56 C66 64 60 74 56 84 Z"
            fill={hair} stroke={OUT} strokeWidth={SW} strokeLinejoin="round"
          />
          <path d="M96 30 C104 40 120 46 138 48" fill="none" stroke="#5a3a26" strokeWidth={3} strokeLinecap="round" />
          {/* eyes */}
          <ellipse cx="88" cy="94" rx="5" ry={6.5 * blink} fill={OUT} />
          <ellipse cx="124" cy="94" rx="5" ry={6.5 * blink} fill={OUT} />
          {/* mouth when talking */}
          {talking && (
            <ellipse cx="106" cy="120" rx="6" ry={1.5 + Math.abs(Math.sin(f * 0.9)) * 3.5} fill="#5b2a22" />
          )}
        </g>
      </g>

      {/* floating microphone (held like a pawn's weapon) */}
      <g transform={`translate(0 ${micY}) rotate(-28 178 160)`}>
        <rect x="171" y="150" width="14" height="62" rx="5" fill="#2a2a2a" stroke={OUT} strokeWidth={4} />
        <rect x="165" y="132" width="26" height="22" rx="3" fill={tie} stroke={OUT} strokeWidth={4} />
        <text x="178" y="148" textAnchor="middle" fontFamily="Anton, sans-serif" fontSize="12" fill="#fff">RCN</text>
        <circle cx="178" cy="120" r="17" fill="#8e949c" stroke={OUT} strokeWidth={4} />
        <path d="M166 114 L190 114 M164 121 L192 121 M166 128 L190 128" stroke="#5d636b" strokeWidth={2} />
      </g>
    </svg>
  );
};
